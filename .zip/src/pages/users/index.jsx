import React from "react";
import Tables from "../../components/table";

const users = () => {
    return(
        <>
            <Tables/>
        </>
    );
}

export default users;