import React from "react";

const EditEducationalDetails = () => {
  return (
    <div className="mt-4 ">
      <div className="mt-7">
        <div className="flex">
          <h3 className=" text-[18px] font-semibold">
            ECE-Bachelor of Engineering(2018-2022)
          </h3>
          <i class="ri-pencil-line font-extrabold text-blue-700 ml-2"></i>
        </div>
        <p className="text-base text-gray-400 ">
          We have to set initial state value inside constructor function and set
        </p>
        <p className="text-base text-gray-400 ">
          We have to set initial state value inside constructor function and set
        </p>
      </div>
      <div className="mt-10">
        <div className="flex">
          <h3 className="text-[18px] font-semibold">DECE-Diploma(2016-2018)</h3>
          <i class="ri-pencil-line font-extrabold text-blue-700 ml-2"></i>
        </div>
        <p className="text-base text-gray-400 ">
          We have to set initial state value inside constructor function and set
        </p>
        <p className="text-base text-gray-400 ">
          We have to set initial state value inside constructor function and set
        </p>
      </div>
      <div className="mt-10">
        <div className="flex">
          <h3 className="text-[18px] font-semibold">SSLC-(2008-2018)</h3>
          <i class="ri-pencil-line font-extrabold text-blue-700 ml-2"></i>
        </div>
        <p className="text-base text-gray-400 ">
          We have to set initial state value inside constructor function and set
        </p>
        <p className="text-base text-gray-400 ">
          We have to set initial state value inside constructor function and set
        </p>
      </div>
    </div>
  );
};

export default EditEducationalDetails;
