import { Button, Tabs } from "antd";
import React from "react";
import image from "../../../assets/Images/forgot.png";

const ViewEducationalDetails = () => {
  return (
    <div className="mt-4 ">
      <div className="mt-7">
        <h3 className=" text-[18px] font-semibold">
          ECE-Bachelor of Engineering(2018-2022)
        </h3>
        <p className="text-base text-gray-400 ">
          We have to set initial state value inside constructor function and set
        </p>
        <p className="text-base text-gray-400 ">
          We have to set initial state value inside constructor function and set
        </p>
      </div>
      <div className="mt-10">
        <h3 className="text-[18px] font-semibold">DECE-Diploma(2016-2018)</h3>
        <p className="text-base text-gray-400 ">
          We have to set initial state value inside constructor function and set
        </p>
        <p className="text-base text-gray-400 ">
          We have to set initial state value inside constructor function and set
        </p>
      </div>
      <div className="mt-10">
        <h3 className="text-[18px] font-semibold">SSCL-0th(2010)</h3>
        <p className="text-base text-gray-400 ">
          We have to set initial state value inside constructor function and set
        </p>
        <p className="text-base text-gray-400 ">
          We have to set initial state value inside constructor function and set
        </p>
      </div>
    </div>
  );
};

export default ViewEducationalDetails;
