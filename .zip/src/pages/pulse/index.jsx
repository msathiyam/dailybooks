import React from 'react';
import CommingSoon from '../commingSoon';

export default function Pulse() {
  return (
      <CommingSoon/>
  )
}
