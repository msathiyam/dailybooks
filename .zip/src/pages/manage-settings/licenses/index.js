import React from 'react';

export default function Goals() {
  return (
<div className='px-10 py-5'>
  <h1 className='font-bold text-base'>License Info</h1>
   <h1 className='font- semibold text-base py-3'>License type:  Extended</h1>
</div>
    )
}
