import React from 'react';
import CommingSoon from '../../../components/comming-soon';

export default function Goals() {
  return (
    <div>
      <CommingSoon/>
      </div>
  )
}
