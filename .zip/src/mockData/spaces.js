export const SpaceIconsList = [
    {
      id: 1,
      name: "contacts-book-line",

    },
    {
      id: 2,
      name: "user-line",

    },
    {
      id: 3,
      name: "apple-fill",

    },
    {
      id: 4,
      name: "app-store-fill",

    },
    {
      id: 5,
      name: "amazon-fill",
 
    },
    {
      id: 6,
      name: "chrome-fill",

    },
    {
      id: 7,
      name: "github-fill",

    },
    {
      id: 8,
      name: "signal-wifi-fill",

    },
    {
      id: 9,
      name: "home-4-line",

    },
    {
      id: 10,
      name: "notification-3-line",

    },
    {
      id: 11,
      name: "trophy-line",

    },
    {
      id: 12,
      name: "inbox-archive-line",

    },
    {
      id: 13,
      name: "lock-line",

    },
    {
      id: 14,
      name: "flag-line",
  
    },
    {
      id: 15,
      name: "star-line",

    },
    {
      id: 16,
      name: "calendar-check-line",

    },
    {
      id: 17,
      name: "global-line",
  
    },
    {
      id: 18,
      name: "price-tag-3-line",
     
    },
    {
      id: 19,
      name: "clipboard-line",
    
    },
    {
      id: 20,
      name: "time-line",

    },
  ];