// import Home from '../pages/home';
// import User from '../pages/users';
// import CommingSoon from "../components/comming-soon";
// import ErrorBoundary from "../pages/error";
// import Login from "../pages/signIn/SignIn-SignUp";
// import ForgotPassword from "../pages/signIn/ForgotPassword";
// import Expenses from "../pages/expenses/expenses";
// import Dashboard2 from "../pages/dashboard 2";
// import Dashboard from "../pages/dashboard";
// import Business from "../pages/Business";
// import Subscriptions from "../pages/Sales/subscriptions";
// import Orders from "../pages/Sales/orders";
// import Payment from "../pages/Finance/payments";
// import Refunds from "../pages/Finance/refunds";
// import PaymentGrievances from "../pages/Finance/Payment Grivences";
// import Report from "../pages/Finance/Reports";
// import Ticket from "../pages/Help disk/tickets";
// import Complaint from "../pages/Help disk/complaints";
// import WebNotification from "../pages/Settings/webnotifications";
// import MobileNotification from "../pages/Settings/mobilenotifications";
// import Customer from "../pages/Sales/Customers";
// import Makepayment from "../pages/Finance/payments/makepayment";
// const protectedRoutes = [
//   {
//     path: "/",
//     component: <Dashboard />,
//     exact: true,
//   },
//   {
//     path: "/performances",
//     component: <Dashboard2 />,
//     exact: true,
//   },
//   {
//     path: "/customer",
//     component: <Customer />,
//     exact: true,
//   },
//   {
//     path: "/business",
//     component: <Business />,
//     exact: true,
//   },
//   {
//     path: "/subscription",
//     component: <Subscriptions />,
//     exact: true,
//   },
//   {
//     path: "/orders",
//     component: <Orders />,
//     exact: true,
//   },
//   {
//     path: "/payment",
//     component: <Payment />,
//     exact: true,
//   },
//   {
//     path: "/refund",
//     component: <Refunds />,
//     exact: true,
//   },
//   {
//     path: "/makepayment",
//     component: <Makepayment />,
//     exact: true,
//   },
//   {
//     path: "/payment-grievances",
//     component: <PaymentGrievances />,
//     exact: true,
//   },
//   {
//     path: "/report",
//     component: <Report />,
//     exact: true,
//   },
//   {
//     path: "/ticket",
//     component: <Ticket />,
//     exact: true,
//   },
//   {
//     path: "/complaints",
//     component: <Complaint />,
//     exact: true,
//   },
//   {
//     path: "/Web-notification",
//     component: <WebNotification />,
//     exact: true,
//   },
//   {
//     path: "/mobile-motifications",
//     component: <MobileNotification />,
//     exact: true,
//   },
//   {
//     path: "/users",
//     component: <User />,
//     exact: true,
//   },
//   {
//     path: "/error",
//     component: <ErrorBoundary />,
//     exact: true,
//   },
//   {
//     path: "/comming-soon",
//     component: <CommingSoon />,
//     exact: true,
//   },
// ];

// const publicRoutes = [
//   {
//     path: "/signin-signup",
//     component: <Login />,
//     exact: true,
//   },
//   {
//     path: "/forgot-password",
//     component: <ForgotPassword />,
//     exact: true,
//   },

//   {
//     path: "/expenses",
//     component: <Expenses />,
//     exact: true,
//   },
// ];

// export {
//     protectedRoutes,
//     publicRoutes
// };
