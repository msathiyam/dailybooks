// import React from "react";

// import { Navigate, Outlet } from "react-router-dom";
// import { isUserLoggedIn } from "../utils/helper";

// const ProtectedRoutes = (props) => {
//   const auth = isUserLoggedIn();
//   console.log("auth======", auth);
//   // return auth ? <Outlet /> : <Navigate to="/" />;
//   return !auth ? <Navigate to="/" /> : <Outlet />;
// };

// export default ProtectedRoutes;
