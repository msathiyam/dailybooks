import React from 'react'

export default function index() {
  return (
    <div className='py-5 text-center'>
        <p>&copy; Copyright 2022 Terolo</p> 
    </div>
  )
}
